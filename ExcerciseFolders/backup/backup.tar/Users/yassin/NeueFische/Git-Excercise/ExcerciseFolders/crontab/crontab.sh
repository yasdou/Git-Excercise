#!/bin/bash
i=$(ls /Users/yassin/NeueFische/Git-Excercise/ExcerciseFolders/crontab | wc -l)
i=$(($i+0))
touch /Users/yassin/NeueFische/Git-Excercise/ExcerciseFolders/crontab/file_date$i.txt
date > /Users/yassin/NeueFische/Git-Excercise/ExcerciseFolders/crontab/file_date$i.txt

#*1 * * * * touch /Users/yassin/Desktop/file_date$i.txt